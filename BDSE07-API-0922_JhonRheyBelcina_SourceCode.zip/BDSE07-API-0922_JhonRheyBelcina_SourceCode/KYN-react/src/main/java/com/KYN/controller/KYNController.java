package com.KYN.controller;

import org.springframework.stereotype.Controller;

@Controller
public class KYNController{
	
	
}