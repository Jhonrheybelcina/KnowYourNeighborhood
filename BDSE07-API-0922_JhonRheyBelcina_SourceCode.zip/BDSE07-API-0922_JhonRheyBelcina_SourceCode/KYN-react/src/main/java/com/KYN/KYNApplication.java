package com.KYN;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KYNApplication {

	public static void main(String[] args) {
		SpringApplication.run(KYNApplication.class, args);
	}

}
