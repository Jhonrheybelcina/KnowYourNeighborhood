import React, { Component } from "react";

class Terms_and_Condition extends Component {
  render() {
    return (
      <div className="container3" style={{marginBottom: "100px"}}>
        <form className="form3">
          <h1>Terms and Conditions</h1>

          <div className="flex-column">
            <label>1. Introduction</label>
            <p>Welcome to our website. These terms and conditions govern your use of our website; by using our website, you accept these terms and conditions in full. If you disagree with these terms and conditions or any part of these terms and conditions, you must not use our website.</p>
          </div>

          <div className="flex-column">
            <label>2. Intellectual Property Rights</label>
            <p>Unless otherwise stated, we or our licensors own the intellectual property rights in the website and material on the website. Subject to the license below, all these intellectual property rights are reserved.</p>
          </div>

          <div className="flex-column">
            <label>3. Restrictions</label>
            <p>You are granted a limited license only for purposes of viewing the material contained on this Website. You must not:</p>
            <ul>
              <li>Republish material from this website</li>
              <li>Sell, rent, or sub-license material from this website</li>
              <li>Reproduce, duplicate, or copy material from this website</li>
              <li>Redistribute content from this website</li>
            </ul>
          </div>

          <div className="flex-column">
            <label>4. Disclaimer</label>
            <p>The information on this website is provided on an "as is" basis. We make no warranties, expressed or implied, and hereby disclaim and negate all other warranties, including without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
          </div>

          <div className="flex-column">
            <label>5. Limitations</label>
            <p>In no event shall we or our suppliers be liable for any damages arising out of the use or inability to use the materials on this website, even if we or our authorized representative have been notified orally or in writing of the possibility of such damage.</p>
          </div>

          <div className="flex-column">
            <label>6. Indemnity</label>
            <p>You agree to indemnify and hold us harmless from any claim or demand, including reasonable attorneys' fees, made by any third party due to or arising out of your breach of these terms and conditions or the documents they incorporate by reference, or your violation of any law or the rights of a third party.</p>
          </div>

          <div className="flex-column">
            <label>7. Governing Law</label>
            <p>These terms and conditions shall be governed by and construed in accordance with the laws of Philippines, and any disputes relating to these terms and conditions will be subject to the exclusive jurisdiction of the courts of [your country].</p>
          </div>

          <div className="flex-column">
            <label>8. Changes to Terms and Conditions</label>
            <p>We reserve the right to revise these terms and conditions at any time without notice. By using this website, you are agreeing to be bound by the then-current version of these terms and conditions.</p>
          </div>

          <button className="button-submit" type="submit">Accept</button>
        </form>
      </div>
    );
  }
}

export default Terms_and_Condition;
