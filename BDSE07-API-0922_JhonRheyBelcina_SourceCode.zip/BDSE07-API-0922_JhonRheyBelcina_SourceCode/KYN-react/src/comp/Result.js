import { Component } from "react"

class Result extends Component{
    render() {
        return(
            <div>
                <h1>Result Page</h1>
            </div>
        );
    }
}
export default Result;