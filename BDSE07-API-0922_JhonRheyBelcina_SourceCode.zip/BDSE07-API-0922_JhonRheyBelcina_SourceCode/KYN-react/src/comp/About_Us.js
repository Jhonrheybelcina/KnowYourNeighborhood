import React, { Component } from "react";

class About_Us extends Component {
  render() {
    return (
      <div
        className="container mt-5"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
          marginBottom: "110px"

        }}
      >
        <div
          style={{
            width: "70%",
            boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.2)",
            padding: "20px",
            borderRadius: "20px",
            backgroundColor: "#FFFFFF",
          }}
        >
          <h1 className="text-center m-5">About Us</h1>
          <div style={{ marginBottom: "20px" }}>
            <div
              style={{
                boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.2)",
                padding: "20px",
                borderRadius: "8px",
                backgroundColor: "#FFFFFF",
              }}
            >
              <p className="m-1">
                Welcome to Know Your Neighborhood! We are dedicated to providing you with detailed information about your
                neighborhood, including local attractions, amenities, schools, and more. Our mission is to help you explore and
                discover everything your neighborhood has to offer.
              </p>
            </div>
          </div>
          <div style={{ marginBottom: "20px" }}>
            <div
              style={{
                boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.2)",
                padding: "20px",
                borderRadius: "8px",
                backgroundColor: "#FFFFFF",
              }}
            >
              <p className="m-1">
                Whether you are new to the area or have been living here for years, our platform aims to enhance your
                neighborhood experience. We strive to provide accurate and up-to-date information, empowering you to make
                informed decisions about your community.
              </p>
            </div>
          </div>
          <div style={{ marginBottom: "20px" }}>
            <div
              style={{
                boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.2)",
                padding: "20px",
                borderRadius: "8px",
                backgroundColor: "#FFFFFF",
              }}
            >
              <p className="m-1">
                At Know Your Neighborhood, we believe that a strong community begins with knowledge and connection. Our goal is
                to foster a sense of belonging and create a platform that brings neighbors together. Through our website, you can
                explore local events, connect with fellow residents, and stay informed about the latest news and updates.
              </p>
            </div>
          </div>
          <div style={{ marginBottom: "20px" }}>
            <div
              style={{
                boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.2)",
                padding: "20px",
                borderRadius: "8px",
                backgroundColor: "#FFFFFF",
              }}
            >
              <p className="m-1">
                Thank you for choosing Know Your Neighborhood. We hope you find our platform helpful and enjoy discovering the
                hidden gems of your neighborhood.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default About_Us;
