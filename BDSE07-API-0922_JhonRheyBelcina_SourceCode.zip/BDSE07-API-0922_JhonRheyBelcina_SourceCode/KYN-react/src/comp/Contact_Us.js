import React, { Component } from "react";
import axios from "axios";

class Contact_Us extends Component {
  state = {
    userName: "Administrator",
    messageText: "",
  };

  handleInputChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  handleSubmit = async (event) => {
    // event.preventDefault();
    const { userName, messageText } = this.state;

    if (!userName || !messageText) {
      console.log("Please enter a username and a message");
      return;
    }

    const message = {
      text: messageText,
    };

    try {
      const response = await axios.post(
        `http://localhost:8081/messages/${userName}`,
        message
      );
      console.log("Message sent successfully:", response.data);
    } catch (error) {
      console.error("Failed to send message:", error);
    }
  };

  render() {
    const { userName, messageText } = this.state;

    return (
      <div className="container justify-content-center align-items-center"style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "70vh",
        width: "70%",
        marginBottom: "80px"
      }}>
        <div className="card form">
          <h1>Contact Us</h1>
          <p>
            We would love to hear from you! If you have any questions, suggestions, or feedback, please feel free to contact us using the form below.
          </p>
          <form onSubmit={this.handleSubmit}>
            <div className="flex-column">
              <label htmlFor="name">Receiver</label>
              <div className="inputForm">
                <input
                  type="text"
                  name="userName"
                  value={userName}
                  onChange={this.handleInputChange}
                  className="input"
                  placeholder="Username"
                  disabled
                />
              </div>
            </div>
            <div className="flex-column">
              <label htmlFor="message">Message</label>
              <div className="inputForm">
                <input
                  placeholder="Message"
                  className="input"
                  type="text"
                  name="messageText"
                  value={messageText}
                  onChange={this.handleInputChange}
                />
              </div>
            </div>
            <button className="button-submit" type="submit">Send Message</button>
          </form>
          <p>
            You can also reach us by email at <a href="mailto:info@knowyourneighborhood.com">info@knowyourneighborhood.com</a> or by phone at <a href="tel:+1234567890">+1234567890</a>.
          </p>
        </div>
      </div>
    );
  }
}

export default Contact_Us;
