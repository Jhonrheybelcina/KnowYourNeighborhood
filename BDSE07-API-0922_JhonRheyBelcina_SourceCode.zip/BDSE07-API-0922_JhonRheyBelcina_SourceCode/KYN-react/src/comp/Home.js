import React, { Component } from "react";

class Home extends Component {
  render() {
    return (
      <div
      className="container"
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "70vh",
        width: "70%",
        marginBottom: "100px"
      }}
    >
        <main>
          <section className="text-center" style={{borderRadius: "10px"}}>
            <div className="card shadow mx-auto"  style={{borderRadius: "10px"}}>
              <div className="card-body">
                <h2>Welcome!</h2>
                <p>
                  At Know Your Neighborhood, we believe that knowing your neighbors
                  and your community is the foundation to a happy and healthy
                  lifestyle. Our mission is to help you get to know your
                  neighborhood through our interactive and engaging platform.
                </p>
                <button className="custom-btn btn-12">
                  <span>
                    <a href="Login" className="text-dark">Click!</a>
                  </span>
                  <span>Learn More</span>
                </button>
              </div>
            </div>
          </section>
          <section className="text-center">
            <div className="card shadow mx-auto">
              <div className="card-body">
                <h2>Get Involved</h2>
                <p>
                  Whether you're looking to volunteer or just want to get involved
                  in your community, Know Your Neighborhood has something for you.
                  Check out our community events calendar and find something that
                  interests you.
                </p>
                <button className="custom-btn btn-12">
                  <span>
                    <a href="Login" className="text-dark">Click!</a>
                  </span>
                  <span>Learn More</span>
                </button>
              </div>
            </div>
          </section>
        </main>
      </div>
    );
  }
}

export default Home;
