/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable react/jsx-pascal-case */
import './App.css';
import './footer.css';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './comp/Home';
import Login from './comp/Login';
import Register from './comp/Register';
import About_Us from './comp/About_Us';
import Contact_Us from './comp/Contact_Us';
import Result from './comp/Result';
import Terms_and_Condition from './comp/Terms_and_Condition';
import React, { useState, useEffect } from "react";

const App = () => {
  // const [isLoggedIn, setIsLoggedIn] = useState(false); // Set the login status here
  const [loggedIn, setLoggedIn] = useState(false); // State to track login status
  const isLoggedIn = localStorage.getItem("loggedIn") === "true";
  const handleLogout = () => {
    localStorage.setItem('loggedIn', false); // Set the 'success' value in local storage to false
    localStorage.removeItem('userEmail')
    localStorage.removeItem('userEmail')
    window.location.reload();
  };

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("loggedIn") === "true";
    setLoggedIn(isLoggedIn); // Update the state based on the value in local storage
  }, []);

  

  return (
    <Router>
      <div
        style={{
          backgroundColor: "#330055",
          backgroundImage: "url('data:image/svg+xml,%3Csvg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 1000\"%3E%3Cg%3E%3Ccircle fill=\"%23330055\" cx=\"50\" cy=\"0\" r=\"50\"/%3E%3Cg fill=\"%233a015d\"%3E%3Ccircle cx=\"0\" cy=\"50\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"50\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%23410165\" cx=\"50\" cy=\"100\" r=\"50\"/%3E%3Cg fill=\"%2348026e\"%3E%3Ccircle cx=\"0\" cy=\"150\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"150\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%23500376\" cx=\"50\" cy=\"200\" r=\"50\"/%3E%3Cg fill=\"%2357047e\"%3E%3Ccircle cx=\"0\" cy=\"250\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"250\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%235f0587\" cx=\"50\" cy=\"300\" r=\"50\"/%3E%3Cg fill=\"%2367068f\"%3E%3Ccircle cx=\"0\" cy=\"350\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"350\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%236f0798\" cx=\"50\" cy=\"400\" r=\"50\"/%3E%3Cg fill=\"%237707a0\"%3E%3Ccircle cx=\"0\" cy=\"450\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"450\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%238008a9\" cx=\"50\" cy=\"500\" r=\"50\"/%3E%3Cg fill=\"%238909b1\"%3E%3Ccircle cx=\"0\" cy=\"550\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"550\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%239109ba\" cx=\"50\" cy=\"600\" r=\"50\"/%3E%3Cg fill=\"%239a09c3\"%3E%3Ccircle cx=\"0\" cy=\"650\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"650\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%23a309cb\" cx=\"50\" cy=\"700\" r=\"50\"/%3E%3Cg fill=\"%23ad09d4\"%3E%3Ccircle cx=\"0\" cy=\"750\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"750\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%23b608dc\" cx=\"50\" cy=\"800\" r=\"50\"/%3E%3Cg fill=\"%23c007e5\"%3E%3Ccircle cx=\"0\" cy=\"850\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"850\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%23c905ee\" cx=\"50\" cy=\"900\" r=\"50\"/%3E%3Cg fill=\"%23d303f6\"%3E%3Ccircle cx=\"0\" cy=\"950\" r=\"50\"/%3E%3Ccircle cx=\"100\" cy=\"950\" r=\"50\"/%3E%3C/g%3E%3Ccircle fill=\"%23D0F\" cx=\"50\" cy=\"1000\" r=\"50\"/%3E%3C/g%3E%3C/svg%3E')",
          backgroundAttachment: "fixed",
          backgroundSize: "contain"
        }}
      >
        <div>
        {loggedIn ? (
          <nav>
          <ul>      
                <header className="text-white">
                  <nav className="navbar navbar-expand-lg navbar-dark">
                    <Link to="/" className="navbar-brand">KYN</Link>
                    <button
                      className="navbar-toggler"
                      type="button"
                      data-toggle="collapse"
                      data-target="#navbarNav"
                      aria-controls="navbarNav"
                      aria-expanded="false"
                      aria-label="Toggle navigation"
                    >
                      <span className="navbar-toggler-icon"></span>
                    </button>
                    <div
                      className="collapse navbar-collapse"
                      id="navbarNav"
                      style={{ paddingLeft: "700px" }}
                    >
                      <ul className="navbar-nav">
                        <li className="nav-item">
                          <Link to="/" className="nav-link">Home</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/login" className="nav-link">Login</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/register" className="nav-link">Register</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/about_Us" className="nav-link">About Us</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/contact_us" className="nav-link">Contact Us</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/terms_and_condition" className="nav-link">Terms and Conditions</Link>
                        </li>
                        <li className="nav-item">
                        <Link className="nav-link" onClick={handleLogout} >Logout</Link>
                        </li>
                        
                      </ul>
                    </div>
                  </nav>
                </header>
            
          </ul>
        </nav>
        ): (
<nav>
          <ul>      
                <header className="text-white">
                  <nav className="navbar navbar-expand-lg navbar-dark">
                    <Link to="/" className="navbar-brand">KYN</Link>
                    <button
                      className="navbar-toggler"
                      type="button"
                      data-toggle="collapse"
                      data-target="#navbarNav"
                      aria-controls="navbarNav"
                      aria-expanded="false"
                      aria-label="Toggle navigation"
                    >
                      <span className="navbar-toggler-icon"></span>
                    </button>
                    <div
                      className="collapse navbar-collapse"
                      id="navbarNav"
                      style={{ paddingLeft: "700px" }}
                    >
                      <ul className="navbar-nav">
                        <li className="nav-item">
                          <Link to="/" className="nav-link">Home</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/login" className="nav-link">Login</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/register" className="nav-link">Register</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/about_Us" className="nav-link">About Us</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/contact_us" className="nav-link">Contact Us</Link>
                        </li>
                        <li className="nav-item">
                          <Link to="/terms_and_condition" className="nav-link">Terms and Conditions</Link>
                        </li>
                      </ul>
                    </div>
                  </nav>
                </header>
            
          </ul>
        </nav>
        )

        };
</div>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/result" element={<Result />} />
          <Route path="/about_Us" element={<About_Us />} />
          <Route path="/contact_us" element={<Contact_Us />} />
          <Route path="/terms_and_condition" element={<Terms_and_Condition />} />
        </Routes>

        <footer id="dk-footer" class="dk-footer">
  <div className="container1">
    <div className="" style={{display: "flex",
                                  flexWrap: "wrap",
                                  marginLeft: "-15px"}}>
      <div className="col-md-12 col-lg-4">
        <div className="dk-footer-box-info">
          <p className="footer-info-text" style={{color: "white"}}>Know Your Neighborhood - for within its streets and corners lies a treasure trove of stories, cultures, and connections waiting to be discovered.</p>
          <div className="footer-social-link">
            <h3>Follow us</h3>
            <ul>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <div className="footer-awarad">
          <p>Know Your Neighborhood</p>
        </div>
      </div>
      <div className="col-md-12 col-lg-8">
        <div className="" style={{display: "flex",
                                  flexWrap: "wrap",
                                  marginLeft: "-15px"}}>
          <div className="col-md-6">
            <div className="contact-us">
              <div className="contact-icon">
                <i className="fa fa-map-o" aria-hidden="true"></i>
              </div>
              <div className="contact-info">
                <h3>Anytown USA</h3>
                <p>123 Main Street</p>
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <div className="contact-us contact-us-last">
              <div className="contact-icon">
                <i className="fa fa-volume-control-phone" aria-hidden="true"></i>
              </div>
              <div className="contact-info">
                <h3>555-1234</h3>
                <p>Give us a call</p>
              </div>
            </div>
          </div>
        </div>
        <div className="" style={{display: "flex",
                                  flexWrap: "wrap",
                                  marginLeft: "-15px"}}>
          <div className="col-md-12 col-lg-6">
            <div className="footer-widget footer-left-widget">
              <div className="section-heading">
                <h3>Useful Links</h3>
                <span className="animate-border border-black"></span>
              </div>
              <ul>
                <li><a href="About_Us">About us</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Projects</a></li>
                <li><a href="#">Our Team</a></li>
              </ul>
              <ul>
                <li><a href="Contact_Us">Contact us</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Testimonials</a></li>
                <li><a href="#">Faq</a></li>
              </ul>
            </div>
          </div>
          <div className="col-md-12 col-lg-6">
            <div className="footer-widget">
              <div className="section-heading">
                <h3>Subscribe</h3>
                <span className="animate-border border-black"></span>
              </div>
              <p style={{color: "white"}}>"Discover the heart and soul of your neighborhood. Join us and unlock the hidden gems, forge meaningful connections, and become a true local expert. Know Your Neighborhood and let its vibrant tapestry enrich your life."</p>
              <form action="#">
                <div className="form-row">
                  <div class="col dk-footer-form">
                    <input type="email" className="form-control" placeholder="Email Address"/>
                    <button type="submit"><i className="fa fa-send"></i></button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div className="copyright">
    <div className="container1">
      <div className="" style={{display: "flex",
                                  flexWrap: "wrap",
                                  marginLeft: "-15px"}}>
        <div className="col-md-5 p">
          <span>© 2023 ABC Cars Company. All Rights Reserved.</span>
        </div>
        <div className="col-md-5">
          <div className="copyright-menu">
            <ul>
              <li><a href="/">Home</a></li>
              <li><a href="/terms_and_conditions">Terms and Conditions</a></li>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="/contact_Us">Contact</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="back-to-top" class="back-to-top">
    <i className="fa fa-angle-up"></i>
  </div>
</footer>

      </div>

    </Router>
  );
};

export default App;
